import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/mock_data.dart';
import '../widgets/shared_widgets.dart';
import 'now_playing_screen.dart';
import 'playlist_detail_screen.dart';

class LibraryScreen extends StatefulWidget {
  final Function(MockSong) onPlaySong;
  const LibraryScreen({super.key, required this.onPlaySong});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      appBar: AppBar(
        backgroundColor: AppTheme.black,
        title: const Text(
          'My Library',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: AppTheme.textWhite, size: 28),
            onPressed: () => _showCreatePlaylistDialog(context),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.netflixRed,
          indicatorWeight: 2,
          labelColor: AppTheme.netflixRed,
          unselectedLabelColor: AppTheme.textMuted,
          labelStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
          tabs: const [
            Tab(text: 'Playlists'),
            Tab(text: 'Liked'),
            Tab(text: 'History'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _PlaylistsTab(onPlaySong: widget.onPlaySong),
          _LikedTab(onPlaySong: widget.onPlaySong),
          _HistoryTab(onPlaySong: widget.onPlaySong),
        ],
      ),
    );
  }

  void _showCreatePlaylistDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.cardGrey,
        title: const Text(
          'Create Playlist',
          style: TextStyle(color: AppTheme.textWhite),
        ),
        content: TextField(
          style: const TextStyle(color: AppTheme.textWhite),
          decoration: InputDecoration(
            hintText: 'Playlist name',
            hintStyle: const TextStyle(color: AppTheme.textMuted),
            filled: true,
            fillColor: AppTheme.surfaceGrey,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textMuted),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.netflixRed,
            ),
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Create', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// playlist tab
class _PlaylistsTab extends StatelessWidget {
  final Function(MockSong) onPlaySong;
  const _PlaylistsTab({required this.onPlaySong});

  @override
  Widget build(BuildContext context) {
    final playlists = MockData.playlists;
    return ListView(
      children: [
        // Liked Songs special card
        _SpecialLibraryCard(
          icon: Icons.favorite,
          title: 'Liked Songs',
          subtitle: '${MockData.likedSongs.length} songs',
          gradient: const LinearGradient(
            colors: [Color(0xFF5B2D8E), Color(0xFF1A0040)],
          ),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => LikedSongsScreen(onPlaySong: onPlaySong),
            ),
          ),
        ),
        // History special card
        _SpecialLibraryCard(
          icon: Icons.history,
          title: 'Recently Played',
          subtitle: '${MockData.recentHistory.length} songs',
          gradient: const LinearGradient(
            colors: [Color(0xFF8B0000), Color(0xFF1A0040)],
          ),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => HistoryScreen(onPlaySong: onPlaySong),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            'Your Playlists',
            style: TextStyle(
              color: AppTheme.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 1,
            ),
          ),
        ),
        ...playlists.map(
          (pl) => _PlaylistListTile(
            playlist: pl,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PlaylistDetailScreen(
                  playlist: pl,
                  onPlaySong: onPlaySong,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 100),
      ],
    );
  }
}

class _SpecialLibraryCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final LinearGradient gradient;
  final VoidCallback? onTap;

  const _SpecialLibraryCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
        height: 72,
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(icon, color: AppTheme.textWhite, size: 28),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: AppTheme.textWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: AppTheme.textLight,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.play_circle_fill, color: Colors.white, size: 36),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlaylistListTile extends StatelessWidget {
  final MockPlaylist playlist;
  final VoidCallback? onTap;

  const _PlaylistListTile({required this.playlist, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: SizedBox(
                width: 52,
                height: 52,
                child: playlist.songs.isNotEmpty
                    ? GridView.count(
                        crossAxisCount: 2,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.zero,
                        children: playlist.songs
                            .take(4)
                            .map(
                              (s) => Container(
                                color: AppTheme.surfaceGrey,
                                child: s.thumbnailUrl != null
                                    ? CachedNetworkImage(
                                        fadeInDuration: Duration.zero,
                                        imageUrl: s.thumbnailUrl!,
                                        fit: BoxFit.cover,
                                        errorWidget: (_, __, ___) =>
                                            const Icon(
                                              Icons.music_note,
                                              color: AppTheme.textMuted,
                                              size: 12,
                                            ),
                                      )
                                    : const Icon(
                                        Icons.music_note,
                                        color: AppTheme.textMuted,
                                        size: 12,
                                      ),
                              ),
                            )
                            .toList(),
                      )
                    : Container(
                        color: AppTheme.surfaceGrey,
                        child: const Icon(
                          Icons.queue_music,
                          color: AppTheme.textMuted,
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    playlist.name,
                    style: const TextStyle(
                      color: AppTheme.textWhite,
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    '${playlist.songs.length} songs',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.more_vert, color: AppTheme.textMuted, size: 20),
          ],
        ),
      ),
    );
  }
}

class _LikedTab extends StatelessWidget {
  final Function(MockSong) onPlaySong;
  const _LikedTab({required this.onPlaySong});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Header banner
        Container(
          margin: const EdgeInsets.all(16),
          height: 90,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF5B2D8E), Color(0xFF1A0040)],
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.favorite, color: Colors.white, size: 32),
                SizedBox(height: 4),
                Text(
                  'Liked Songs',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: ListView(
            children: [
              ...MockData.likedSongs.asMap().entries.map(
                (e) => SongTile(
                  song: e.value,
                  index: e.key,
                  onTap: () {
                    onPlaySong(e.value);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => NowPlayingScreen(song: e.value),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 180),
            ],
          ),
        ),
      ],
    );
  }
}

// history tab
class _HistoryTab extends StatelessWidget {
  final Function(MockSong) onPlaySong;
  const _HistoryTab({required this.onPlaySong});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            'TODAY',
            style: TextStyle(
              color: AppTheme.textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
            ),
          ),
        ),
        ...MockData.recentHistory.take(4).map(
              (s) => SongTile(
                song: s,
                onTap: () {
                  onPlaySong(s);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NowPlayingScreen(song: s),
                    ),
                  );
                },
              ),
            ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
          child: Text(
            'YESTERDAY',
            style: TextStyle(
              color: AppTheme.textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
            ),
          ),
        ),
        ...MockData.recentHistory.skip(4).map(
              (s) => SongTile(
                song: s,
                onTap: () {
                  onPlaySong(s);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NowPlayingScreen(song: s),
                    ),
                  );
                },
              ),
            ),
        const SizedBox(height: 100),
      ],
    );
  }
}
