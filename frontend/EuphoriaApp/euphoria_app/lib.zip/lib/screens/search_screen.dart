import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/mock_data.dart';
import '../widgets/shared_widgets.dart';
import 'now_playing_screen.dart';
import 'artist_detail_screen.dart';
import 'album_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  final Function(MockSong) onPlaySong;
  const SearchScreen({super.key, required this.onPlaySong});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  String _query = '';
  String _selectedGenre = 'All';

  static const List<String> _genres = [
    'All',
    'Pop',
    'Hip-Hop',
    'R&B',
    'Rock',
    'Jazz',
    'Electronic',
    'Country',
  ];

  List<MockSong> get _filteredSongs {
    var songs = MockData.songs.toList();
    if (_selectedGenre != 'All') {
      songs = songs.where((s) => s.genre == _selectedGenre).toList();
    }
    if (_query.isNotEmpty) {
      songs = songs
          .where(
            (s) =>
                s.title.toLowerCase().contains(_query.toLowerCase()) ||
                s.artistName.toLowerCase().contains(_query.toLowerCase()),
          )
          .toList();
    }
    return songs;
  }

  List<MockArtist> get _filteredArtists {
    if (_query.isEmpty) return [];
    return MockData.artists
        .where((a) => a.name.toLowerCase().contains(_query.toLowerCase()))
        .toList();
  }

  List<MockAlbum> get _filteredAlbums {
    if (_query.isEmpty) return [];
    return MockData.albums
        .where(
          (a) =>
              a.title.toLowerCase().contains(_query.toLowerCase()) ||
              a.artistName.toLowerCase().contains(_query.toLowerCase()),
        )
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      appBar: AppBar(
        backgroundColor: AppTheme.black,
        title: const Text(
          'Search',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
        ),
      ),
      body: Column(
        children: [
          // search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _controller,
              onChanged: (v) => setState(() => _query = v),
              style: const TextStyle(color: AppTheme.textWhite),
              decoration: InputDecoration(
                hintText: 'Songs, artists, albums...',
                hintStyle: const TextStyle(color: AppTheme.textMuted),
                prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted),
                suffixIcon: _query.isNotEmpty
                    ? GestureDetector(
                        onTap: () => setState(() {
                          _query = '';
                          _controller.clear();
                        }),
                        child: const Icon(
                          Icons.close,
                          color: AppTheme.textMuted,
                        ),
                      )
                    : null,
                filled: true,
                fillColor: AppTheme.surfaceGrey,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // genre chips
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _genres.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => GenreChip(
                label: _genres[i],
                selected: _selectedGenre == _genres[i],
                onTap: () => setState(() => _selectedGenre = _genres[i]),
              ),
            ),
          ),

          const SizedBox(height: 8),

          // results
          Expanded(
            child: _query.isEmpty && _selectedGenre == 'All'
                ? _buildBrowseView()
                : _buildResults(),
          ),
        ],
      ),
    );
  }

  Widget _buildBrowseView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          const Text(
            'Browse Categories',
            style: TextStyle(
              color: AppTheme.textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 2.5,
            children: [
              _CategoryTile(label: 'Pop', color: const Color(0xFF1DB954)),
              _CategoryTile(label: 'Hip-Hop', color: const Color(0xFF8B5CF6)),
              _CategoryTile(label: 'R&B', color: const Color(0xFFEC4899)),
              _CategoryTile(label: 'Rock', color: const Color(0xFFF59E0B)),
              _CategoryTile(label: 'Jazz', color: const Color(0xFF06B6D4)),
              _CategoryTile(
                label: 'Electronic',
                color: const Color(0xFF10B981),
              ),
              _CategoryTile(label: 'Country', color: const Color(0xFFEF4444)),
              _CategoryTile(label: 'Classical', color: const Color(0xFF3B82F6)),
            ],
          ),
          const SizedBox(height: 180),
        ],
      ),
    );
  }

  Widget _buildResults() {
    return ListView(
      children: [
        if (_filteredArtists.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Artists',
              style: TextStyle(
                color: AppTheme.textWhite,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ..._filteredArtists.map(
            (a) => ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 4,
              ),
              leading: ClipOval(
                child: Container(
                  width: 50,
                  height: 50,
                  color: AppTheme.surfaceGrey,
                  child: CachedNetworkImage(
                    fadeInDuration: Duration.zero,
                    imageUrl: a.imgUrl,
                    fit: BoxFit.cover,
                    errorWidget: (_, __, ___) =>
                        const Icon(Icons.person, color: AppTheme.textMuted),
                  ),
                ),
              ),
              title: Text(
                a.name,
                style: const TextStyle(
                  color: AppTheme.textWhite,
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: const Text(
                'Artist',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
              ),
              trailing: const Icon(
                Icons.chevron_right,
                color: AppTheme.textMuted,
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ArtistDetailScreen(
                    artist: a,
                    onPlaySong: widget.onPlaySong,
                  ),
                ),
              ),
            ),
          ),
        ],
        if (_filteredAlbums.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Albums',
              style: TextStyle(
                color: AppTheme.textWhite,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ..._filteredAlbums.map(
            (a) => ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 4,
              ),
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: Container(
                  width: 50,
                  height: 50,
                  color: AppTheme.surfaceGrey,
                  child: CachedNetworkImage(
                    fadeInDuration: Duration.zero,
                    imageUrl: a.coverImgUrl,
                    fit: BoxFit.cover,
                    errorWidget: (_, __, ___) =>
                        const Icon(Icons.album, color: AppTheme.textMuted),
                  ),
                ),
              ),
              title: Text(
                a.title,
                style: const TextStyle(
                  color: AppTheme.textWhite,
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: Text(
                a.artistName,
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
              ),
              trailing: const Icon(
                Icons.chevron_right,
                color: AppTheme.textMuted,
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AlbumDetailScreen(
                    album: a,
                    onPlaySong: widget.onPlaySong,
                  ),
                ),
              ),
            ),
          ),
        ],
        if (_filteredSongs.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Songs',
              style: TextStyle(
                color: AppTheme.textWhite,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ..._filteredSongs.map(
            (s) => SongTile(
              song: s,
              onTap: () {
                widget.onPlaySong(s);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => NowPlayingScreen(song: s)),
                );
              },
            ),
          ),
        ],
        if (_filteredSongs.isEmpty &&
            _filteredArtists.isEmpty &&
            _filteredAlbums.isEmpty)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                children: [
                  const Icon(
                    Icons.search_off,
                    color: AppTheme.textMuted,
                    size: 60,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No results for "$_query"',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 180),
      ],
    );
  }
}

class _CategoryTile extends StatelessWidget {
  final String label;
  final Color color;

  const _CategoryTile({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Not implemented yet!')),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.4)),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }
}
