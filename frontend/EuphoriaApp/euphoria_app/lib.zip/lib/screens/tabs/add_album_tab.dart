import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/user.dart';
import '../../services/api_service.dart';

class AddAlbumTab extends StatefulWidget {
  const AddAlbumTab({super.key});

  @override
  State<AddAlbumTab> createState() => _AddAlbumTabState();
}

class _AddAlbumTabState extends State<AddAlbumTab> {
  final _titleController = TextEditingController();
  Artist? _selectedArtist;
  List<Artist> _artists = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadArtists();
  }

  Future<void> _loadArtists() async {
    final artists = await ApiService.fetchArtists();
    if (mounted) setState(() { _artists = artists; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Center(child: CircularProgressIndicator(color: AppTheme.netflixRed));

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 600),
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            _buildInputLabel('Album Title'),
            _buildTextField(_titleController, 'e.g. Starboy'),
            const SizedBox(height: 16),
            _buildInputLabel('Artist'),
            Container(
              decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
              child: DropdownButtonFormField<Artist>(
                dropdownColor: AppTheme.surfaceGrey,
                decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 16)),
                items: _artists.map((a) => DropdownMenuItem(value: a, child: Text(a.name, style: const TextStyle(color: Colors.white)))).toList(),
                onChanged: (val) => setState(() => _selectedArtist = val),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.netflixRed, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: const Text('Add Album'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputLabel(String label) => Padding(
    padding: const EdgeInsets.only(left: 4, bottom: 8),
    child: Text(label, style: const TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
  );

  Widget _buildTextField(TextEditingController controller, String hint) => Container(
    decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
    child: TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(hintText: hint, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
    ),
  );
}
