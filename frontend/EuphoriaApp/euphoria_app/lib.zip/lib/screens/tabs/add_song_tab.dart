import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';
import '../../models/user.dart';

class AddSongTab extends StatefulWidget {
  const AddSongTab({super.key});

  @override
  State<AddSongTab> createState() => _AddSongTabState();
}

class _AddSongTabState extends State<AddSongTab> {
  final _titleController = TextEditingController();
  final _genreController = TextEditingController();
  final _durationController = TextEditingController();
  
  Artist? _selectedArtist;
  List<Artist> _artists = [];
  PlatformFile? _audioFile;
  PlatformFile? _thumbnailFile;
  bool _isLoading = true;
  bool _isUploading = false;

  @override
  void initState() {
    super.initState();
    _loadArtists();
  }

  Future<void> _loadArtists() async {
    final artists = await ApiService.fetchArtists();
    if (mounted) setState(() { _artists = artists; _isLoading = false; });
  }

  Future<void> _upload() async {
    if (_titleController.text.isEmpty || _selectedArtist == null || _audioFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Missing fields')));
      return;
    }

    setState(() => _isUploading = true);
    final success = await ApiService.uploadSong(
      title: _titleController.text,
      artistId: _selectedArtist!.id,
      genre: _genreController.text,
      durationSeconds: int.tryParse(_durationController.text) ?? 180,
      audioFile: _audioFile!,
      thumbnailFile: _thumbnailFile,
    );

    if (mounted) {
      setState(() => _isUploading = false);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Song Uploaded!')));
        _titleController.clear();
        _genreController.clear();
        _durationController.clear();
        setState(() { _audioFile = null; _thumbnailFile = null; });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Upload failed.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Center(child: CircularProgressIndicator(color: AppTheme.netflixRed));

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 600),
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            _buildInputLabel('Song Title'),
            _buildTextField(_titleController, 'e.g. Blinding Lights'),
            const SizedBox(height: 16),
            
            _buildInputLabel('Genre'),
            _buildTextField(_genreController, 'e.g. Pop'),
            const SizedBox(height: 16),
            
            _buildInputLabel('Artist'),
            Container(
              decoration: BoxDecoration(
                color: AppTheme.surfaceGrey.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.borderGrey),
              ),
              child: DropdownButtonFormField<Artist>(
                dropdownColor: AppTheme.surfaceGrey,
                decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 16)),
                items: _artists.map((a) => DropdownMenuItem(value: a, child: Text(a.name, style: const TextStyle(color: Colors.white)))).toList(),
                onChanged: (val) => setState(() => _selectedArtist = val),
              ),
            ),
            
            const SizedBox(height: 16),
            _buildFilePicker('Audio File', Icons.audiotrack, _audioFile, () async {
              final res = await FilePicker.platform.pickFiles(type: FileType.audio);
              if (res != null) setState(() => _audioFile = res.files.first);
            }),
            const SizedBox(height: 12),
            _buildFilePicker('Cover Thumbnail', Icons.image, _thumbnailFile, () async {
              final res = await FilePicker.platform.pickFiles(type: FileType.image);
              if (res != null) setState(() => _thumbnailFile = res.files.first);
            }),
            
            const SizedBox(height: 32),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _isUploading ? null : _upload,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.netflixRed,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: Text(_isUploading ? 'Uploading...' : 'Upload to Cloudinary'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputLabel(String label) => Padding(
    padding: const EdgeInsets.only(left: 4, bottom: 8),
    child: Text(label, style: const TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
  );

  Widget _buildTextField(TextEditingController controller, String hint) => Container(
    decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
    child: TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(hintText: hint, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
    ),
  );

  Widget _buildFilePicker(String label, IconData icon, PlatformFile? file, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12),
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
      child: Row(
        children: [
          Icon(icon, color: file != null ? Colors.green : AppTheme.textMuted),
          const SizedBox(width: 12),
          Expanded(child: Text(file?.name ?? label, style: TextStyle(color: file != null ? Colors.white : AppTheme.textMuted))),
        ],
      ),
    ),
  );
}
