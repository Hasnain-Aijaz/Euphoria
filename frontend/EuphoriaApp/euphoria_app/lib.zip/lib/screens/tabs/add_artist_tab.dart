import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';

class AddArtistTab extends StatefulWidget {
  const AddArtistTab({super.key});

  @override
  State<AddArtistTab> createState() => _AddArtistTabState();
}

class _AddArtistTabState extends State<AddArtistTab> {
  final _nameController = TextEditingController();
  final _bioController = TextEditingController();
  PlatformFile? _imageFile;
  bool _isUploading = false;

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null) setState(() => _imageFile = result.files.first);
  }

  Future<void> _submit() async {
    if (_nameController.text.isEmpty || _imageFile == null) return;
    setState(() => _isUploading = true);
    // TODO: Implement ApiService.createArtist
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _isUploading = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Artist Added!')));
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 600),
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            _buildInputLabel('Artist Name'),
            _buildTextField(_nameController, 'e.g. The Weeknd'),
            const SizedBox(height: 16),
            _buildInputLabel('Biography'),
            _buildTextField(_bioController, 'Write artist biography...', maxLines: 3),
            const SizedBox(height: 16),
            _buildFilePicker('Artist Image', Icons.person, _imageFile, _pickImage),
            const SizedBox(height: 32),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _isUploading ? null : _submit,
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.netflixRed, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: Text(_isUploading ? 'Adding...' : 'Add Artist'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputLabel(String label) => Padding(
    padding: const EdgeInsets.only(left: 4, bottom: 8),
    child: Text(label, style: const TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
  );

  Widget _buildTextField(TextEditingController controller, String hint, {int maxLines = 1}) {
    return Container(
      decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(hintText: hint, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
      ),
    );
  }

  Widget _buildFilePicker(String label, IconData icon, PlatformFile? file, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppTheme.surfaceGrey.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderGrey)),
        child: Row(
          children: [
            Icon(icon, color: file != null ? Colors.green : AppTheme.textMuted),
            const SizedBox(width: 12),
            Expanded(child: Text(file?.name ?? label, style: TextStyle(color: file != null ? Colors.white : AppTheme.textMuted))),
          ],
        ),
      ),
    );
  }
}
