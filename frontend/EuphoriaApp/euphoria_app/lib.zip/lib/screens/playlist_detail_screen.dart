import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/mock_data.dart';
import '../widgets/shared_widgets.dart';
import 'now_playing_screen.dart';

class PlaylistDetailScreen extends StatelessWidget {
  final MockPlaylist playlist;
  final Function(MockSong) onPlaySong;

  const PlaylistDetailScreen({
    super.key,
    required this.playlist,
    required this.onPlaySong,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: CustomScrollView(
        slivers: [
          // app bar
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: AppTheme.black,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: AppTheme.textWhite),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Gradient bg based on title
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF5B2D8E), Color(0xFF1A0040)],
                      ),
                    ),
                  ),
                  // Grid of 4 covers or single icon
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Container(
                        width: 180,
                        height: 180,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.4),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: playlist.songs.isNotEmpty
                            ? GridView.count(
                                crossAxisCount: 2,
                                padding: EdgeInsets.zero,
                                physics: const NeverScrollableScrollPhysics(),
                                children: playlist.songs
                                    .take(4)
                                    .map(
                                      (s) => Container(
                                        color: AppTheme.surfaceGrey,
                                        child: s.thumbnailUrl != null
                                            ? CachedNetworkImage(
                                                fadeInDuration: Duration.zero,
                                                imageUrl: s.thumbnailUrl!,
                                                fit: BoxFit.cover,
                                                errorWidget: (_, __, ___) =>
                                                    const Icon(
                                                      Icons.music_note,
                                                      color: AppTheme.textMuted,
                                                    ),
                                              )
                                            : const Icon(
                                                Icons.music_note,
                                                color: AppTheme.textMuted,
                                              ),
                                      ),
                                    )
                                    .toList(),
                              )
                            : Container(
                                color: AppTheme.surfaceGrey,
                                child: const Icon(
                                  Icons.queue_music,
                                  color: AppTheme.textMuted,
                                  size: 60,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Info
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        playlist.name,
                        style: const TextStyle(
                          color: AppTheme.textWhite,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${playlist.description} • ${playlist.songs.length} songs',
                        style: const TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),

                // actions
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Row(
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.netflixRed,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                        ),
                        onPressed: () {
                          if (playlist.songs.isNotEmpty) {
                            onPlaySong(playlist.songs.first);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => NowPlayingScreen(
                                  song: playlist.songs.first,
                                ),
                              ),
                            );
                          }
                        },
                        icon: const Icon(Icons.play_arrow, size: 22),
                        label: const Text(
                          'Play',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      IconButton(
                        icon: const Icon(
                          Icons.favorite_border,
                          color: AppTheme.textMuted,
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Not implemented yet!'),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.download_for_offline_outlined,
                          color: AppTheme.textMuted,
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Not implemented yet!'),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.more_vert,
                          color: AppTheme.textMuted,
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Not implemented yet!'),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),

                // tracks
                ...playlist.songs.asMap().entries.map(
                      (e) => SongTile(
                        song: e.value,
                        index: e.key,
                        onTap: () {
                          onPlaySong(e.value);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NowPlayingScreen(song: e.value),
                            ),
                          );
                        },
                      ),
                    ),

                const SizedBox(height: 180),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class LikedSongsScreen extends StatelessWidget {
  final Function(MockSong) onPlaySong;
  const LikedSongsScreen({super.key, required this.onPlaySong});

  @override
  Widget build(BuildContext context) {
    final songs = MockData.likedSongs;
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: AppTheme.black,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: AppTheme.textWhite),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF5B2D8E), Color(0xFF1A0040)],
                  ),
                ),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.favorite, color: Colors.white, size: 50),
                      SizedBox(height: 8),
                      Text(
                        'Liked Songs',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 24,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate(
              [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Text(
                        '${songs.length} songs',
                        style: const TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 14,
                        ),
                      ),
                      const Spacer(),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.netflixRed,
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Not implemented yet!'),
                            ),
                          );
                        },
                        child: const Text(
                          'Shuffle Play',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
                ...songs.asMap().entries.map(
                      (e) => SongTile(
                        song: e.value,
                        index: e.key,
                        onTap: () {
                          onPlaySong(e.value);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NowPlayingScreen(song: e.value),
                            ),
                          );
                        },
                      ),
                    ),
                const SizedBox(height: 180),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryScreen extends StatelessWidget {
  final Function(MockSong) onPlaySong;
  const HistoryScreen({super.key, required this.onPlaySong});

  @override
  Widget build(BuildContext context) {
    final songs = MockData.recentHistory;
    return Scaffold(
      backgroundColor: AppTheme.black,
      appBar: AppBar(
        title: const Text(
          'Recent History',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Not implemented yet!')),
              );
            },
            child: const Text(
              'Clear',
              style: TextStyle(color: AppTheme.netflixRed),
            ),
          ),
        ],
      ),
      body: ListView(
        children: [
          ...songs.map(
            (s) => SongTile(
              song: s,
              onTap: () {
                onPlaySong(s);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => NowPlayingScreen(song: s),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 180),
        ],
      ),
    );
  }
}
