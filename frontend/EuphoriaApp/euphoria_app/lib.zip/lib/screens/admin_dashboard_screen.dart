import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'tabs/add_artist_tab.dart';
import 'tabs/add_album_tab.dart';
import 'tabs/add_song_tab.dart';

import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'tabs/add_artist_tab.dart';
import 'tabs/add_album_tab.dart';
import 'tabs/add_song_tab.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppTheme.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Admin Dashboard', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(60),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: AppTheme.surfaceGrey.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TabBar(
                indicator: BoxDecoration(
                  color: AppTheme.netflixRed,
                  borderRadius: BorderRadius.circular(12),
                ),
                labelColor: Colors.white,
                unselectedLabelColor: AppTheme.textMuted,
                tabs: const [
                  Tab(text: 'Artists'),
                  Tab(text: 'Albums'),
                  Tab(text: 'Songs'),
                ],
              ),
            ),
          ),
        ),
        body: const TabBarView(
          children: [
            AddArtistTab(),
            AddAlbumTab(),
            AddSongTab(),
          ],
        ),
      ),
    );
  }
}
