import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/mock_data.dart';
import '../widgets/shared_widgets.dart';
import 'now_playing_screen.dart';
import 'album_detail_screen.dart';

class ArtistDetailScreen extends StatefulWidget {
  final MockArtist artist;
  final Function(MockSong) onPlaySong;

  const ArtistDetailScreen({
    super.key,
    required this.artist,
    required this.onPlaySong,
  });

  @override
  State<ArtistDetailScreen> createState() => _ArtistDetailScreenState();
}

class _ArtistDetailScreenState extends State<ArtistDetailScreen> {
  bool _isFollowing = false;

  @override
  Widget build(BuildContext context) {
    final artist = widget.artist;
    final songs = MockData.songsForArtist(artist.id);
    final albums = MockData.albumsForArtist(artist.id);

    return Scaffold(
      backgroundColor: AppTheme.black,
      body: CustomScrollView(
        slivers: [
          // hero header
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: AppTheme.black,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: AppTheme.textWhite),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(
                    tag: 'artist_${artist.id}',
                    child: CachedNetworkImage(
                      fadeInDuration: Duration.zero,
                      imageUrl: artist.imgUrl,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) =>
                          Container(color: AppTheme.surfaceGrey),
                    ),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, AppTheme.black],
                        stops: [0.5, 1.0],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          artist.name,
                          style: const TextStyle(
                            color: AppTheme.textWhite,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // action row
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _isFollowing
                                ? AppTheme.netflixRed
                                : AppTheme.textWhite,
                            side: BorderSide(
                              color: _isFollowing
                                  ? AppTheme.netflixRed
                                  : AppTheme.borderGrey,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          onPressed: () =>
                              setState(() => _isFollowing = !_isFollowing),
                          child: Text(_isFollowing ? 'Following' : 'Follow'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.netflixRed,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                        ),
                        onPressed: () {
                          if (songs.isNotEmpty) {
                            widget.onPlaySong(songs.first);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    NowPlayingScreen(song: songs.first),
                              ),
                            );
                          }
                        },
                        icon: const Icon(Icons.play_arrow, size: 18),
                        label: const Text('Play All'),
                      ),
                    ],
                  ),
                ),

                // bio
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Text(
                    artist.bio,
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 13,
                      height: 1.5,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

                // popular songs
                SectionHeader(title: 'Popular Songs'),
                ...songs.asMap().entries.map(
                      (e) => SongTile(
                        song: e.value,
                        index: e.key,
                        showPlayCount: true,
                        onTap: () {
                          widget.onPlaySong(e.value);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NowPlayingScreen(song: e.value),
                            ),
                          );
                        },
                      ),
                    ),

                // albums
                if (albums.isNotEmpty) ...[
                  SectionHeader(title: 'Albums'),
                  SizedBox(
                    height: 180,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: albums.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, i) => AlbumCard(
                        album: albums[i],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AlbumDetailScreen(
                              album: albums[i],
                              onPlaySong: widget.onPlaySong,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],

                const SizedBox(height: 180),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
