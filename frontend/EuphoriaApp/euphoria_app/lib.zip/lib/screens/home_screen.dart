import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:ui';
import '../theme/app_theme.dart';
import '../models/mock_data.dart';
import '../widgets/shared_widgets.dart';
import 'album_detail_screen.dart';
import 'artist_detail_screen.dart';
import 'now_playing_screen.dart';
import 'playlist_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final Function(int) onNavigate;
  final Function(MockSong) onPlaySong;

  const HomeScreen({
    super.key,
    required this.onNavigate,
    required this.onPlaySong,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedGenre = 'All';
  final List<String> _genres = ['All', 'Pop', 'Rock', 'Dance', 'R&B', 'Jazz', 'Lo-Fi'];
  late MockSong _featuredSong;

  @override
  void initState() {
    super.initState();
    _pickFeaturedSong();
  }

  void _pickFeaturedSong() {
    // Select a song based on the current day of the year to simulate a daily refresh
    final dayOfYear = DateTime.now().difference(DateTime(DateTime.now().year, 1, 1)).inDays;
    final index = dayOfYear % MockData.songs.length;
    _featuredSong = MockData.songs[index];
  }

  void _showNotImplemented(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Not implemented yet!')),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // app bar
          SliverAppBar(
            floating: true,
            pinned: false,
            backgroundColor: AppTheme.black,
            elevation: 0,
            title: Row(
              children: [
                // Mini glowing logo
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.netflixRed.withOpacity(0.5),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/euphoria_logo1.png',
                      fit: BoxFit.cover,
                      filterQuality: FilterQuality.high,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Stylized Brand Text
                const Text(
                  'E U P H O R I A',
                  style: TextStyle(
                    color: AppTheme.textWhite,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(
                  Icons.notifications_none,
                  color: AppTheme.textWhite,
                  size: 26,
                ),
                onPressed: () => _showNotImplemented(context),
              ),
              GestureDetector(
                onTap: () => widget.onNavigate(3),
                child: Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: CircleAvatar(
                    radius: 15,
                    backgroundColor: AppTheme.netflixRed,
                    child: Text(
                      MockData.currentUser.name[0],
                      style: const TextStyle(
                        color: AppTheme.textWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Clean Text Greeting with Gradient Name
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _getGreeting(),
                        style: TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 14,
                        ),
                      ),
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [Color(0xFFE50914), Color(0xFF8B0000), Color(0xFF1A0040)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ).createShader(bounds),
                        child: Text(
                          MockData.currentUser.name.split(' ').first,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Genre Quick Filters
                const SizedBox(height: 24),
                SizedBox(
                  height: 40,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _genres.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, i) {
                      final genre = _genres[i];
                      bool isSelected = _selectedGenre == genre;
                      return GenreChip(
                        label: genre,
                        selected: isSelected,
                        onTap: () => setState(() => _selectedGenre = genre),
                      );
                    },
                  ),
                ),

                // featured banner (Dynamic)
                const SizedBox(height: 24),
                _FeaturedBanner(
                  song: _featuredSong,
                  onTap: () {
                    widget.onPlaySong(_featuredSong);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            NowPlayingScreen(song: _featuredSong),
                      ),
                    );
                  },
                ),

                // quick access row (Fixed stretching)
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _QuickChip(
                        icon: Icons.favorite,
                        label: 'Liked Songs',
                        onTap: () => widget.onNavigate(2),
                      ),
                      _QuickChip(
                        icon: Icons.history,
                        label: 'Recent',
                        onTap: () => widget.onNavigate(2),
                      ),
                      _QuickChip(
                        icon: Icons.playlist_play,
                        label: 'Playlists',
                        onTap: () => widget.onNavigate(2),
                      ),
                    ],
                  ),
                ),

                // treding now
                SectionHeader(title: 'Trending Now', onSeeAll: () {}),
                SizedBox(
                  height: 200, // Fixed height to prevent overflow
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: MockData.albums.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 16),
                    itemBuilder: (context, i) {
                      final album = MockData.albums[i];
                      return AlbumCard(
                        album: album,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AlbumDetailScreen(
                              album: album,
                              onPlaySong: widget.onPlaySong,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // top artist
                SectionHeader(title: 'Top Artists', onSeeAll: () {}),
                SizedBox(
                  height: 200, // Increased height to prevent overflow
                  child: ListView.separated(

                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: MockData.artists.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 20),
                    itemBuilder: (context, i) {
                      final artist = MockData.artists[i];
                      return ArtistCard(
                        artist: artist,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ArtistDetailScreen(
                              artist: artist,
                              onPlaySong: widget.onPlaySong,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // recently played
                SectionHeader(title: 'Recently Played'),
                ...MockData.recentHistory.take(5).map(
                      (song) => SongTile(
                        song: song,
                        onTap: () {
                          widget.onPlaySong(song);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NowPlayingScreen(song: song),
                            ),
                          );
                        },
                      ),
                    ),

                // your playlists
                SectionHeader(
                  title: 'Your Playlists',
                  onSeeAll: () => widget.onNavigate(2),
                ),
                SizedBox(
                  height: 240, // Increased height
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: MockData.playlists.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, i) {
                      final pl = MockData.playlists[i];
                      return PlaylistCard(
                        playlist: pl,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PlaylistDetailScreen(
                              playlist: pl,
                              onPlaySong: widget.onPlaySong,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 180),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// featured banner
class _FeaturedBanner extends StatefulWidget {
  final MockSong song;
  final VoidCallback onTap;
  const _FeaturedBanner({required this.song, required this.onTap});

  @override
  State<_FeaturedBanner> createState() => _FeaturedBannerState();
}

class _FeaturedBannerState extends State<_FeaturedBanner> {
  bool _isHovered = false;

  void _showNotImplemented(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Not implemented yet!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(horizontal: 16),
          height: 190,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: _isHovered ? [
              BoxShadow(
                color: const Color(0xFF8B0000).withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 2,
              )
            ] : [],
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: _isHovered 
                ? [const Color(0xFFA50000), const Color(0xFF2A0050)] 
                : [const Color(0xFF8B0000), const Color(0xFF1A0040)],
            ),
          ),
          child: Stack(
            children: [
              // Background art
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.horizontal(
                    right: Radius.circular(12),
                  ),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: _isHovered ? 180 : 160,
                    child: Opacity(
                      opacity: _isHovered ? 0.7 : 0.5,
                      child: CachedNetworkImage(
                        fadeInDuration: Duration.zero,
                        imageUrl: widget.song.thumbnailUrl ?? 'https://res.cloudinary.com/demo/image/upload/sample.jpg',
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const SizedBox(),
                      ),
                    ),
                  ),
                ),
              ),
              // Dark overlay gradient
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8B0000), Colors.transparent],
                      stops: [0.4, 1.0],
                    ),
                  ),
                ),
              ),
              // Content
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.netflixRed,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'FEATURED',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      widget.song.title,
                      style: const TextStyle(
                        color: AppTheme.textWhite,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.song.artistName,
                      style: const TextStyle(
                        color: AppTheme.textLight,
                        fontSize: 14,
                      ),
                    ),

                    const Spacer(),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          onPressed: widget.onTap,
                          icon: const Icon(Icons.play_arrow, size: 18),
                          label: const Text('Play Now'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.netflixRed,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        OutlinedButton.icon(
                          onPressed: () => _showNotImplemented(context),
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('Add'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: const BorderSide(color: Colors.white54),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 8,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickChip extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  const _QuickChip({required this.icon, required this.label, this.onTap});

  @override
  State<_QuickChip> createState() => _QuickChipState();
}

class _QuickChipState extends State<_QuickChip> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: _isHovered ? Colors.white.withOpacity(0.1) : AppTheme.surfaceGrey,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _isHovered ? Colors.white.withOpacity(0.3) : AppTheme.borderGrey,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(widget.icon, size: 14, color: AppTheme.netflixRed),
              const SizedBox(width: 6),
              Text(
                widget.label,
                style: TextStyle(
                  color: _isHovered ? AppTheme.textWhite : AppTheme.textLight,
                  fontSize: 12,
                  fontWeight: _isHovered ? FontWeight.bold : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
