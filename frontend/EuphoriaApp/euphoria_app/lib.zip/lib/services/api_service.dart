import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import '../models/user.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8080'; 

  static Future<List<Artist>> fetchArtists() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/artists'));
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Artist.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  static Future<bool> createArtist({
    required String name,
    required String bio,
    required PlatformFile image,
  }) async {
    try {
      final token = await getToken();
      if (token == null) return false;

      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/artists'));
      request.headers['Authorization'] = 'Bearer $token';

      request.files.add(await http.MultipartFile.fromPath('image', image.path!));
      request.fields['name'] = name;
      request.fields['bio'] = bio;

      final response = await request.send();
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> uploadSong({
    required String title,
    required int artistId,
    required String genre,
    required int durationSeconds,
    required PlatformFile audioFile,
    PlatformFile? thumbnailFile,
    int? albumId,
  }) async {
    try {
      final token = await getToken();
      if (token == null) return false;

      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/songs'));
      
      // Add Headers
      request.headers['Authorization'] = 'Bearer $token';

      // Add JSON Metadata Part
      final songData = jsonEncode({
        'title': title,
        'artistId': artistId,
        'genre': genre,
        'durationSeconds': durationSeconds,
        'albumId': albumId,
      });

      request.files.add(http.MultipartFile.fromString(
        'song',
        songData,
        contentType: http.MediaType('application', 'json'),
      ));

      // Add Audio File
      if (kIsWeb) {
        request.files.add(http.MultipartFile.fromBytes(
          'audio',
          audioFile.bytes!,
          filename: audioFile.name,
        ));
      } else {
        request.files.add(await http.MultipartFile.fromPath(
          'audio',
          audioFile.path!,
        ));
      }

      // Add Thumbnail File
      if (thumbnailFile != null) {
        if (kIsWeb) {
          request.files.add(http.MultipartFile.fromBytes(
            'thumbnail',
            thumbnailFile.bytes!,
            filename: thumbnailFile.name,
          ));
        } else {
          request.files.add(await http.MultipartFile.fromPath(
            'thumbnail',
            thumbnailFile.path!,
          ));
        }
      }

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print('Upload Error: $e');
      return false;
    }
  }

  static Future<String?> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final token = response.body;
        await _saveToken(token);
        return null; // No error
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return 'Connection error. Is the backend running?';
    }
  }

  static Future<String?> register(String username, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        return null; // Success
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return 'Connection error. Is the backend running?';
    }
  }

  static Future<User?> getMe() async {
    try {
      final token = await getToken();
      if (token == null) return null;

      final response = await http.get(
        Uri.parse('$baseUrl/users/me'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        return User.fromJson(jsonDecode(response.body));
      } else {
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  static Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('jwt_token', token);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('jwt_token');
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('jwt_token');
  }

  static String _handleError(http.Response response) {
    try {
      final data = jsonDecode(response.body);
      return data['message'] ?? 'An unexpected error occurred';
    } catch (_) {
      return 'Error: ${response.statusCode}';
    }
  }
}
