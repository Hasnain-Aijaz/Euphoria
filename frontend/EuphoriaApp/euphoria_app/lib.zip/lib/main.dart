import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'dart:ui';
import 'theme/app_theme.dart';
import 'models/mock_data.dart';
import 'screens/home_screen.dart';
import 'screens/search_screen.dart';
import 'screens/library_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/now_playing_screen.dart';
import 'screens/splash_screen.dart';
import 'widgets/shared_widgets.dart';

void main() {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  runApp(const EuphoriaApp());
}

class EuphoriaApp extends StatelessWidget {
  const EuphoriaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Euphoria',
      theme: AppTheme.theme,
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  int? _hoveredIndex;
  bool _miniPlayerVisible = true;
  bool _isPlaying = true;
  bool _isSidebarExpanded = true;
  MockSong _currentSong = MockData.songs.first;

  void _onNavTap(int index) {
    setState(() => _currentIndex = index);
  }

  void _onPlaySong(MockSong song) {
    setState(() {
      _currentSong = song;
      _isPlaying = true;
    });
  }

  Widget _buildNavItem(
    IconData icon,
    IconData activeIcon,
    String label,
    int index,
  ) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      onTap: () => _onNavTap(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isSelected ? activeIcon : icon,
              color: isSelected
                  ? AppTheme.netflixRed
                  : AppTheme.textWhite.withOpacity(0.5),
              size: isSelected ? 26 : 24,
            ),
            const SizedBox(height: 4),
            AnimatedOpacity(
              duration: const Duration(milliseconds: 250),
              opacity: isSelected ? 1.0 : 0.0,
              child: Container(
                height: 4,
                width: 4,
                decoration: const BoxDecoration(
                  color: AppTheme.netflixRed,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      width: _isSidebarExpanded ? 260 : 80,
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0A),
        border: Border(right: BorderSide(color: AppTheme.borderGrey, width: 1)),
      ),
      child: Column(
        children: [
          // Desktop Logo & Collapse Toggle
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 48, 16, 40),
            child: Row(
              mainAxisAlignment: _isSidebarExpanded ? MainAxisAlignment.spaceBetween : MainAxisAlignment.center,
              children: [
                if (_isSidebarExpanded)
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppTheme.netflixRed.withOpacity(0.4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset('assets/euphoria_logo1.png', fit: BoxFit.cover),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Flexible(
                          child: Text(
                            'EUPHORIA',
                            style: TextStyle(
                              color: AppTheme.textWhite,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.netflixRed.withOpacity(0.4),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset('assets/euphoria_logo1.png', fit: BoxFit.cover),
                    ),
                  ),
                if (_isSidebarExpanded) 
                  IconButton(
                    icon: const Icon(Icons.chevron_left, color: AppTheme.textMuted),
                    onPressed: () => setState(() => _isSidebarExpanded = false),
                  ),
              ],
            ),
          ),
          
          if (!_isSidebarExpanded)
            Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: IconButton(
                icon: const Icon(Icons.chevron_right, color: AppTheme.textMuted),
                onPressed: () => setState(() => _isSidebarExpanded = true),
              ),
            ),

          // Sidebar Items
          _buildSidebarItem(Icons.home_outlined, Icons.home, 'Home', 0),
          _buildSidebarItem(Icons.search, Icons.search, 'Search', 1),
          _buildSidebarItem(Icons.library_music_outlined, Icons.library_music, 'Library', 2),
          _buildSidebarItem(Icons.person_outline, Icons.person, 'Profile', 3),
          const Spacer(),
          // Admin quick entry (Only icon if collapsed)
          if (MockData.currentUser.name == "Admin")
            Padding(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: EdgeInsets.all(_isSidebarExpanded ? 12 : 8),
                decoration: BoxDecoration(
                  color: AppTheme.netflixRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.admin_panel_settings, color: AppTheme.netflixRed, size: 18),
                    if (_isSidebarExpanded) ...[
                      const SizedBox(width: 8),
                      const Flexible(
                        child: Text(
                          'Admin Mode',
                          style: TextStyle(color: AppTheme.netflixRed, fontSize: 12, fontWeight: FontWeight.bold),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSidebarItem(IconData icon, IconData activeIcon, String label, int index) {
    bool isSelected = _currentIndex == index;
    bool isHovered = _hoveredIndex == index;
    
    return MouseRegion(
      onEnter: (_) => setState(() => _hoveredIndex = index),
      onExit: (_) => setState(() => _hoveredIndex = null),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: () => _onNavTap(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 56,
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(
                color: isSelected ? AppTheme.netflixRed : Colors.transparent,
                width: 4,
              ),
            ),
            color: isSelected 
                ? AppTheme.netflixRed.withOpacity(0.08) 
                : (isHovered ? Colors.white.withOpacity(0.05) : Colors.transparent),
          ),
          child: Row(
            mainAxisAlignment: _isSidebarExpanded ? MainAxisAlignment.start : MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: _isSidebarExpanded ? 24 : 0),
                child: Icon(
                  isSelected ? activeIcon : icon,
                  color: (isSelected || isHovered) ? AppTheme.textWhite : AppTheme.textMuted,
                  size: (isSelected || isHovered) ? 26 : 24,
                ),
              ),
              if (_isSidebarExpanded)
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: (isSelected || isHovered) ? AppTheme.textWhite : AppTheme.textMuted,
                      fontWeight: (isSelected || isHovered) ? FontWeight.bold : FontWeight.w500,
                      fontSize: 16,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(onNavigate: _onNavTap, onPlaySong: _onPlaySong),
      SearchScreen(onPlaySong: _onPlaySong),
      LibraryScreen(onPlaySong: _onPlaySong),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: AppTheme.black,
      body: LayoutBuilder(
        builder: (context, constraints) {
          bool isDesktop = constraints.maxWidth >= 900;

          return PopScope(
            canPop: _currentIndex == 0,
            onPopInvoked: (didPop) {
              if (!didPop && _currentIndex != 0) {
                _onNavTap(0);
              }
            },
            child: Row(
              children: [
                if (isDesktop) _buildSidebar(),
                Expanded(
                  child: Stack(
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: screens[_currentIndex],
                      ),
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 900),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // mini player
                                if (_miniPlayerVisible)
                                  MiniPlayer(
                                    song: _currentSong,
                                    isPlaying: _isPlaying,
                                    onPlayPause: () => setState(() => _isPlaying = !_isPlaying),
                                    onTap: () => Navigator.push(
                                      context,
                                      PageRouteBuilder(
                                        pageBuilder: (_, __, ___) =>
                                            NowPlayingScreen(song: _currentSong),
                                        transitionsBuilder: (_, anim, __, child) =>
                                            SlideTransition(
                                              position: Tween<Offset>(
                                                begin: const Offset(0, 1),
                                                end: Offset.zero,
                                              ).animate(anim),
                                              child: child,
                                            ),
                                      ),
                                    ),
                                  ),

                                // bottom dock (Only on mobile)
                                if (!isDesktop)
                                  Container(
                                    margin: const EdgeInsets.only(
                                      left: 24,
                                      right: 24,
                                      bottom: 24,
                                      top: 8,
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(35),
                                      child: BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                                        child: Container(
                                          height: 70,
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.08),
                                            borderRadius: BorderRadius.circular(35),
                                            border: Border.all(
                                              color: Colors.white.withOpacity(0.15),
                                              width: 1,
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.black.withOpacity(0.3),
                                                blurRadius: 20,
                                                offset: const Offset(0, 10),
                                              ),
                                            ],
                                          ),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            children: [
                                              _buildNavItem(Icons.home_outlined, Icons.home, 'Home', 0),
                                              _buildNavItem(Icons.search, Icons.search, 'Search', 1),
                                              _buildNavItem(Icons.library_music_outlined, Icons.library_music, 'Library', 2),
                                              _buildNavItem(Icons.person_outline, Icons.person, 'Profile', 3),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                else 
                                  const SizedBox(height: 20), // Padding for desktop player
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
