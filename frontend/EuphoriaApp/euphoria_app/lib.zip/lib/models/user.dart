class User {
  final int id;
  final String username;
  final String email;
  final String role;
  final String? profileImgUrl;
  final DateTime createdAt;

  User({
    required this.id,
    required this.username,
    required this.email,
    required this.role,
    this.profileImgUrl,
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      username: json['username'],
      email: json['email'],
      role: json['role'],
      profileImgUrl: json['profileImgUrl'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'email': email,
      'role': role,
      'profileImgUrl': profileImgUrl,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  bool get isAdmin => role == 'ADMIN';
}

class Artist {
  final int id;
  final String name;
  final String bio;
  final String imgUrl;

  Artist({required this.id, required this.name, required this.bio, required this.imgUrl});

  factory Artist.fromJson(Map<String, dynamic> json) {
    return Artist(
      id: json['id'],
      name: json['name'],
      bio: json['bio'],
      imgUrl: json['imgUrl'],
    );
  }
}
