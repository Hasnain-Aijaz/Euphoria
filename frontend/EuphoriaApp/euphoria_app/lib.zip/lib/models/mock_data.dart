class MockUser {
  final int id;
  final String name;
  final String email;
  final String? profileImgUrl;

  const MockUser({
    required this.id,
    required this.name,
    required this.email,
    this.profileImgUrl,
  });
}

class MockArtist {
  final int id;
  final String name;
  final String bio;
  final String imgUrl;

  const MockArtist({
    required this.id,
    required this.name,
    required this.bio,
    required this.imgUrl,
  });
}

class MockAlbum {
  final int id;
  final int artistId;
  final String artistName;
  final String title;
  final String coverImgUrl;
  final String releaseDate;

  const MockAlbum({
    required this.id,
    required this.artistId,
    required this.artistName,
    required this.title,
    required this.coverImgUrl,
    required this.releaseDate,
  });
}

class MockSong {
  final int id;
  final int? albumId;
  final int artistId;
  final String title;
  final String artistName;
  final String genre;
  final int durationSeconds;
  final String? thumbnailUrl;
  final int playCount;

  const MockSong({
    required this.id,
    this.albumId,
    required this.artistId,
    required this.title,
    required this.artistName,
    required this.genre,
    required this.durationSeconds,
    this.thumbnailUrl,
    required this.playCount,
  });

  String get durationFormatted {
    final m = durationSeconds ~/ 60;
    final s = durationSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}

class MockPlaylist {
  final int id;
  final int userId;
  final String name;
  final String description;
  final List<MockSong> songs;

  const MockPlaylist({
    required this.id,
    required this.userId,
    required this.name,
    required this.description,
    required this.songs,
  });
}

// seed data

class MockData {
  static const currentUser = MockUser(
    id: 1,
    name: 'Hasnain',
    email: 'admin@example.com',
    profileImgUrl: null,
  );

  static const List<MockArtist> artists = [
    MockArtist(
      id: 1,
      name: 'The Weeknd',
      bio:
          'Abel Makkonen Tesfaye, known professionally as the Weeknd, is a Canadian singer and record producer known for his sonic versatility and dark, sensual themes.',
      imgUrl:
          'https://upload.wikimedia.org/wikipedia/en/c/c1/The_Weeknd_-_After_Hours.png?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=original',
    ),
    MockArtist(
      id: 2,
      name: 'Billie Eilish',
      bio:
          'Billie Eilish Pirate Baird O\'Connell is an American singer-songwriter who has won multiple Grammy awards.',
      imgUrl:
          'https://i0.wp.com/themusicalhype.com/wp-content/uploads/2021/05/billie-eilish-happier-than-ever.jpg?ssl=1',
    ),
    MockArtist(
      id: 3,
      name: 'Drake',
      bio:
          'Aubrey Drake Graham is a Canadian rapper, singer, and actor. He is one of the world\'s best-selling music artists.',
      imgUrl:
          'https://upload.wikimedia.org/wikipedia/en/thumb/c/c6/Drake_-_Iceman.jpg/250px-Drake_-_Iceman.jpg',
    ),
    MockArtist(
      id: 4,
      name: 'Taylor Swift',
      bio:
          'Taylor Alison Swift is an American singer-songwriter known for her songwriting and musical versatility.',
      imgUrl:
          'https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Midnights_-_Taylor_Swift.png/250px-Midnights_-_Taylor_Swift.png',
    ),
    MockArtist(
      id: 5,
      name: 'Kendrick Lamar',
      bio:
          'Kendrick Lamar Duckworth is an American rapper and songwriter widely regarded as one of the most influential rappers of his generation.',
      imgUrl:
          'https://beatsperminute.com/wp-content/uploads/2024/11/kendrick-lamar-gnx-Credit-Dave-Free.jpg',
    ),
  ];

  static const List<MockAlbum> albums = [
    MockAlbum(
      id: 1,
      artistId: 1,
      artistName: 'The Weeknd',
      title: 'After Hours',
      coverImgUrl:
          'https://upload.wikimedia.org/wikipedia/en/c/c1/The_Weeknd_-_After_Hours.png?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=original',
      releaseDate: '2020',
    ),
    MockAlbum(
      id: 2,
      artistId: 1,
      artistName: 'The Weeknd',
      title: 'Starboy',
      coverImgUrl:
          'https://upload.wikimedia.org/wikipedia/en/3/39/The_Weeknd_-_Starboy.png',
      releaseDate: '2016',
    ),
    MockAlbum(
      id: 3,
      artistId: 2,
      artistName: 'Billie Eilish',
      title: 'Happier Than Ever',
      coverImgUrl:
          'https://i0.wp.com/themusicalhype.com/wp-content/uploads/2021/05/billie-eilish-happier-than-ever.jpg?ssl=1',
      releaseDate: '2021',
    ),
    MockAlbum(
      id: 4,
      artistId: 3,
      artistName: 'Drake',
      title: 'Certified Lover Boy',
      coverImgUrl:
          'https://media.pitchfork.com/photos/613214a114458bf5df99f2a9/master/pass/Drake-Certified-Lover-Boy.png',
      releaseDate: '2021',
    ),
    MockAlbum(
      id: 5,
      artistId: 4,
      artistName: 'Taylor Swift',
      title: 'Midnights',
      coverImgUrl:
          'https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Midnights_-_Taylor_Swift.png/250px-Midnights_-_Taylor_Swift.png',
      releaseDate: '2022',
    ),
    MockAlbum(
      id: 6,
      artistId: 5,
      artistName: 'Kendrick Lamar',
      title: 'Mr. Morale',
      coverImgUrl:
          'https://cdn.rapzilla.com/wp-content/uploads/2022/05/23084039/kendrick-mr-morale.jpg',
      releaseDate: '2022',
    ),
  ];

  static const List<MockSong> songs = [
    MockSong(
      id: 1,
      albumId: 1,
      artistId: 1,
      title: 'Blinding Lights',
      artistName: 'The Weeknd',
      genre: 'Pop',
      durationSeconds: 200,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/e/e6/The_Weeknd_-_Blinding_Lights.png',
      playCount: 4500000,
    ),
    MockSong(
      id: 2,
      albumId: 1,
      artistId: 1,
      title: 'Save Your Tears',
      artistName: 'The Weeknd ft. Ariana Grande',
      genre: 'Pop',
      durationSeconds: 215,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/c/c1/The_Weeknd_-_After_Hours.png?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=original',
      playCount: 3200000,
    ),
    MockSong(
      id: 3,
      albumId: 2,
      artistId: 1,
      title: 'Starboy',
      artistName: 'The Weeknd',
      genre: 'R&B',
      durationSeconds: 230,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/3/39/The_Weeknd_-_Starboy.png',
      playCount: 2900000,
    ),
    MockSong(
      id: 4,
      albumId: 3,
      artistId: 2,
      title: 'Happier Than Ever',
      artistName: 'Billie Eilish',
      genre: 'Pop',
      durationSeconds: 298,
      thumbnailUrl:
          'https://i0.wp.com/themusicalhype.com/wp-content/uploads/2021/05/billie-eilish-happier-than-ever.jpg?ssl=1',
      playCount: 2100000,
    ),
    MockSong(
      id: 5,
      albumId: 3,
      artistId: 2,
      title: 'Oxytocin',
      artistName: 'Billie Eilish',
      genre: 'Pop',
      durationSeconds: 174,
      thumbnailUrl:
          'https://i0.wp.com/themusicalhype.com/wp-content/uploads/2021/05/billie-eilish-happier-than-ever.jpg?ssl=1',
      playCount: 1800000,
    ),
    MockSong(
      id: 6,
      albumId: 4,
      artistId: 3,
      title: 'Champagne Poetry',
      artistName: 'Drake',
      genre: 'Hip-Hop',
      durationSeconds: 340,
      thumbnailUrl:
          'https://media.pitchfork.com/photos/613214a114458bf5df99f2a9/master/pass/Drake-Certified-Lover-Boy.png',
      playCount: 1600000,
    ),
    MockSong(
      id: 7,
      albumId: 4,
      artistId: 3,
      title: 'Girls Want Girls',
      artistName: 'Drake',
      genre: 'Hip-Hop',
      durationSeconds: 218,
      thumbnailUrl:
          'https://media.pitchfork.com/photos/613214a114458bf5df99f2a9/master/pass/Drake-Certified-Lover-Boy.png',
      playCount: 1400000,
    ),
    MockSong(
      id: 8,
      albumId: 5,
      artistId: 4,
      title: 'Anti-Hero',
      artistName: 'Taylor Swift',
      genre: 'Pop',
      durationSeconds: 200,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Midnights_-_Taylor_Swift.png/250px-Midnights_-_Taylor_Swift.png',
      playCount: 3800000,
    ),
    MockSong(
      id: 9,
      albumId: 5,
      artistId: 4,
      title: 'Midnight Rain',
      artistName: 'Taylor Swift',
      genre: 'Pop',
      durationSeconds: 174,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Midnights_-_Taylor_Swift.png/250px-Midnights_-_Taylor_Swift.png',
      playCount: 1200000,
    ),
    MockSong(
      id: 10,
      albumId: 6,
      artistId: 5,
      title: 'Not Like Us',
      artistName: 'Kendrick Lamar',
      genre: 'Hip-Hop',
      durationSeconds: 189,
      thumbnailUrl:
          'https://cdn.rapzilla.com/wp-content/uploads/2022/05/23084039/kendrick-mr-morale.jpg',
      playCount: 1900000,
    ),
    MockSong(
      id: 11,
      albumId: 6,
      artistId: 5,
      title: 'Die Hard',
      artistName: 'Kendrick Lamar',
      genre: 'Hip-Hop',
      durationSeconds: 262,
      thumbnailUrl:
          'https://cdn.rapzilla.com/wp-content/uploads/2022/05/23084039/kendrick-mr-morale.jpg',
      playCount: 1700000,
    ),
    MockSong(
      id: 12,
      albumId: 1,
      artistId: 1,
      title: 'Heartless',
      artistName: 'The Weeknd',
      genre: 'R&B',
      durationSeconds: 188,
      thumbnailUrl:
          'https://upload.wikimedia.org/wikipedia/en/c/c1/The_Weeknd_-_After_Hours.png?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=original',
      playCount: 2600000,
    ),
  ];

  static List<MockPlaylist> get playlists => [
    MockPlaylist(
      id: 1,
      userId: 1,
      name: 'Late Night Vibes',
      description: 'For those late night drives',
      songs: [songs[0], songs[1], songs[3], songs[7]],
    ),
    MockPlaylist(
      id: 2,
      userId: 1,
      name: 'Workout Bangers',
      description: 'High energy hits to keep you moving',
      songs: [songs[4], songs[9], songs[2], songs[6]],
    ),
    MockPlaylist(
      id: 3,
      userId: 1,
      name: 'Chill Sunday',
      description: 'Relax and unwind',
      songs: [songs[8], songs[3], songs[10], songs[1]],
    ),
  ];

  static List<MockSong> get likedSongs => [
    songs[0],
    songs[3],
    songs[7],
    songs[9],
    songs[2],
    songs[5],
  ];

  static List<MockSong> get recentHistory => [
    songs[7],
    songs[0],
    songs[4],
    songs[9],
    songs[1],
    songs[6],
    songs[3],
    songs[11],
  ];

  static List<MockSong> songsForArtist(int artistId) =>
      songs.where((s) => s.artistId == artistId).toList();

  static List<MockAlbum> albumsForArtist(int artistId) =>
      albums.where((a) => a.artistId == artistId).toList();

  static List<MockSong> songsForAlbum(int albumId) =>
      songs.where((s) => s.albumId == albumId).toList();
}